<?php 
namespace App\Helper;
use Illuminate\Support\Facades\DB;
class Hsf {
    
    function _cekEmpty($v){
        return (empty($v)=="");
    }
}

?>