<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CrincianBelanja extends Controller
{
    //
}
